$('.main-slider-carousel').owlCarousel({
  animateOut: 'fadeOut',
  animateIn: 'fadeIn',
  loop: true,
  margin: 0,
  nav: false,
  autoplay: false,
  autoplayTimeout: 9000,
  //autoHeight: true,
  smartSpeed: 500,
  //autoplay: 6000,
  navText: ['<span class="flaticon-left-arrow"></span>', '<span class="flaticon-right-arrow"></span>'],
  responsive: {
    0: {
      items: 1
    },
    600: {
      items: 1
    },
    800: {
      items: 1
    },
    1024: {
      items: 1
    },
    1200: {
      items: 1
    }
  }
});


$('#industries-serve').owlCarousel({
  loop: true,
  margin: 10,
  /*stagePadding: 20,*/
  dots: true,
  navigation: false,
  autoplay: true,
  autoplaySpeed: 1000,
  /*slideTransition: 'linear',
  autoplayTimeout: 6000,
  autoplaySpeed: 6000,*/
  autoplayHoverPause: true,
  navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
  responsiveClass: true,
  responsive: {
    0: {
      items: 1
    },
    500: {
      items: 1
    },
    768: {
      items: 1
    },
    1000: {
      items: 3
    }
  }
});
$('#client').owlCarousel({
  loop: true,
  margin: 80,
  /*stagePadding: 20,*/
  dots: true,
  navigation: false,
  autoplay: true,
  autoplaySpeed: 1000,
  /*slideTransition: 'linear',
  autoplayTimeout: 6000,
  autoplaySpeed: 6000,*/
  autoplayHoverPause: true,
  navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
  responsiveClass: true,
  responsive: {
    0: {
      items: 2
    },
    500: {
      items: 2
    },
    768: {
      items: 3
    },
    1000: {
      items: 5
    }
  }
});
$('#testimonials').owlCarousel({
  loop: true,
  margin: 10,
  /*stagePadding: 20,*/
  dots: true,
  navigation: false,
  autoplay: true,
  autoplaySpeed: 1000,
  /*slideTransition: 'linear',
  autoplayTimeout: 6000,
  autoplaySpeed: 6000,*/
  autoplayHoverPause: true,
  navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
  responsiveClass: true,
  responsive: {
    0: {
      items: 1
    },
    500: {
      items: 1
    },
    768: {
      items: 1
    },
    1000: {
      items: 1
    }
  }
});


/*-----------------------------------
   Back to Top
   -----------------------------------*/
var btn = $('#button');

$(window).scroll(function () {
  if ($(window).scrollTop() > 300) {
    btn.addClass('show');
  } else {
    btn.removeClass('show');
  }
});

btn.on('click', function (e) {
  e.preventDefault();
  $('html, body').animate({
    scrollTop: 0
  }, '300');
});


$(document).ready(function () {
  let scroll_link = $('.scroll');

  //smooth scrolling -----------------------
  scroll_link.click(function (e) {
    e.preventDefault();
    let url = $('body').find($(this).attr('href')).offset().top - 60;
    $('html, body').animate({
      scrollTop: url
    }, 700);
    $(this).parent().addClass('active');
    $(this).parent().siblings().removeClass('active');
    return false;
  });
});

//wow js
var wow = new WOW({
  animateClass: 'animated',
  offset: 100,
  mobile: false,
  duration: 1000,
});
wow.init();

//scorl animation js
var $single_portfolio_img = $('.overlay_effect');
var $window = $(window);

function scroll_addclass() {
  var window_height = $(window).height() - 200;
  var window_top_position = $window.scrollTop();
  var window_bottom_position = (window_top_position + window_height);

  $.each($single_portfolio_img, function () {
    var $element = $(this);
    var element_height = $element.outerHeight();
    var element_top_position = $element.offset().top;
    var element_bottom_position = (element_top_position + element_height);

    //check to see if this current container is within viewport
    if ((element_bottom_position >= window_top_position) &&
      (element_top_position <= window_bottom_position)) {
      $element.addClass('is_show');
    }
  });
}

$window.on('scroll resize', scroll_addclass);
$window.trigger('scroll');


$(window).on('load', function () {
  setTimeout(function () { // allowing 3 secs to fade out loader
    $('.page-loader').fadeOut('slow');
  }, 500);
});

// accordion
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function () {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    }
  });
}

// sticky
$(window).on('scroll', function () {
  var scroll = $(window).scrollTop();
  if (scroll < 200) {
    $("#header-sticky").removeClass("sticky-menu");
  } else {
    $("#header-sticky").addClass("sticky-menu");
  }
});

AOS.init({
  duration: 1000,
  once: true,
  disable: 'mobile'
});

/*Counter*/
// number count for stats, using jQuery animate

$('.counting').each(function () {
  var $this = $(this),
    countTo = $this.attr('data-count');

  $({
    countNum: $this.text()
  }).animate({
      countNum: countTo
    },

    {

      duration: 3000,
      easing: 'linear',
      step: function () {
        $this.text(Math.floor(this.countNum));
      },
      complete: function () {
        $this.text(this.countNum);
        //alert('finished');
      }

    });


});

/*Dropdown*/
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function (event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

/*Search popup*/

$(document).ready(function () {
  $('a[href="#search"]').on('click', function (event) {
    $('#search').addClass('open');
    $('#search > form > input[type="search"]').focus();
  });
  $('#search, #search button.close').on('click keyup', function (event) {
    if (event.target == this || event.target.className == 'close' || event.keyCode == 27) {
      $(this).removeClass('open');
    }
  });
});

/*Language Translator*/
function googleTranslateElementInit() {
  new google.translate.TranslateElement({
    pageLanguage: 'en',
    includedLanguages: "hi,mr,gu,ta,ml,ar",
    layout: google.translate.TranslateElement.InlineLayout.SIMPLE
  }, 'google_translate_element');
}

$(document).ready(function () {
  $('#google_translate_element').bind('DOMNodeInserted', function (event) {
    $('.goog-te-menu-value span:first').html('LANGUAGE');
    $('.goog-te-menu-frame.skiptranslate').load(function () {
      setTimeout(function () {
        $('.goog-te-menu-frame.skiptranslate').contents().find('.goog-te-menu2-item-selected .text').html('LANGUAGE');
      }, 100);
    });
  });
});